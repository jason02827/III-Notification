//
//  ViewController.m
//  20170516UserNotification
//
//  Created by user35 on 2017/5/16.
//  Copyright © 2017年 user35. All rights reserved.
//

#import "ViewController.h"
@import UserNotifications;

@interface ViewController ()<UNUserNotificationCenterDelegate>


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    
    UNAuthorizationOptions options = UNAuthorizationOptionAlert +UNAuthorizationOptionSound;
    
    [center requestAuthorizationWithOptions:options completionHandler:^(BOOL granted, NSError * _Nullable error) {
            if (!granted) {
                            NSLog(@"Something went wrong");
                        }
            }];
    
    UNMutableNotificationContent *content = [UNMutableNotificationContent new];
    content.title = @"Don't forget";
    content.body = @"Buy Nintendo Switch";
    content.sound = [UNNotificationSound defaultSound];
    
    UNTimeIntervalNotificationTrigger *trigger =
    [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:4 repeats:NO];
    
    
    NSDate *date = [NSDate dateWithTimeIntervalSinceNow:3600];
    NSDateComponents *triggerDate = [[NSCalendar currentCalendar]
                                     components:/*NSCalendarUnitDay +
                                     NSCalendarUnitHour +
                                     NSCalendarUnitMinute +*/
                                     NSCalendarUnitSecond fromDate:date];
    [UNCalendarNotificationTrigger
     triggerWithDateMatchingComponents:triggerDate repeats:YES];
    
    UNCalendarNotificationTrigger *callTrigger = [UNCalendarNotificationTrigger triggerWithDateMatchingComponents:triggerDate repeats:YES];
    
    
    NSString *identifier = @"ZenLocalNotification";
    UNNotificationRequest *request = [UNNotificationRequest
                                      requestWithIdentifier:identifier content:content trigger:callTrigger];
    [center addNotificationRequest:request withCompletionHandler:^(NSError *
                                                                   _Nullable error) {
        if (error != nil) {
            NSLog(@"Something went wrong: %@",error);
        } }];
    
    center.delegate = self;
}

-(void)userNotificationCenter:(UNUserNotificationCenter *)center
didReceiveNotificationResponse:(UNNotificationResponse *)response
        withCompletionHandler:(void (^)())completionHandler{
    NSLog(@"received notifcation");
    completionHandler();
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
